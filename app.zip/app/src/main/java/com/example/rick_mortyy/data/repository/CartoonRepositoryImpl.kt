package com.example.rick_mortyy.data.repository

import com.example.rick_mortyy.core.Either
import com.example.rick_mortyy.data.api.CartoonApi
import com.example.rick_mortyy.data.base.BaseRepository
import com.example.rick_mortyy.data.mapper.toDomain
import com.example.rick_mortyy.domain.models.Character
import com.example.rick_mortyy.domain.repository.CartoonRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import java.net.SocketTimeoutException
import java.net.UnknownHostException

class CartoonRepositoryImpl(
    private val api: CartoonApi
) : CartoonRepository, BaseRepository() {

    override fun getCharacters(): Flow<Either<String, List<Character>>> {
        return doRequest2 {
            api.getCharacters().characters.toDomain()
        }
    }
}
