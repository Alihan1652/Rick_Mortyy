package com.example.rick_mortyy.data.base

import com.example.rick_mortyy.core.Either
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import kotlin.text.ifEmpty

abstract class BaseRepository {
    protected fun <T> doRequest(
        request: suspend () -> retrofit2.Response<T>
    ): Flow<Either<String, T>> {
        return flow {
                    delay(1000)
                    try {
                        val response = request()
                        if (response.isSuccessful && response.body() != null){
                            response.body()?.let {result ->
                                emit(Either.Right(result))
                            }
                        } else{
                            emit(Either.Left(response.message().ifEmpty { "Unknown error" }))
                        }
                    } catch (e: UnknownHostException) {
                        emit(Either.Left (e.localizedMessage?: "Unknown error"))
                    } catch (e: SocketTimeoutException) {
                        emit(Either.Left(e.localizedMessage?: "Unknown error"))
                    }
                }.flowOn(Dispatchers.IO)
            }

    protected fun <T> doRequest2(
        request: suspend () -> T,
    ): Flow<Either<String, T>> {
        return flow {
            delay(1000)
            try {
                val response = request()
                //if (response.isSuccessful && response.body() != null){
                   // response.body()?.let {result ->
                        emit(Either.Right(response))
               //     }
               // } else{
                 //   emit(Either.Left(response.message().ifEmpty { "Unknown error" }))
               //}
            } catch (e: UnknownHostException) {
                emit(Either.Left (e.localizedMessage?: "Unknown error"))
            } catch (e: SocketTimeoutException) {
                emit(Either.Left(e.localizedMessage?: "Unknown error"))
            }
        }.flowOn(Dispatchers.IO)
    }
        }
