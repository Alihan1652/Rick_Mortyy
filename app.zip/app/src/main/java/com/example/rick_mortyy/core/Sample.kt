package com.example.rick_mortyy.core

class Sample {
}