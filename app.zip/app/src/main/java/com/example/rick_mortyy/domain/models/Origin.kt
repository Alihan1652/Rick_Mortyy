package com.example.rick_mortyy.domain.models

data class Origin(
    val name: String,
    val url: String
)