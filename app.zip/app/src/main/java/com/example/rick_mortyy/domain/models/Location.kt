package com.example.rick_mortyy.domain.models

data class Location(
    val name: String,
    val url: String
)