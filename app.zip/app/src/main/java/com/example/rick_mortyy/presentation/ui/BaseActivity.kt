package com.example.rick_mortyy.presentation.ui

import androidx.lifecycle.ViewModel
import androidx.viewbinding.ViewBinding

class BaseActivity<VB: ViewBinding, VM: ViewModel> {
}